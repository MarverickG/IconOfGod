// data/users.js
const users = [];
module.exports = users;
